let cor;
let posicaoHorizontal;// x // variável horizontal
let posicaoVertical; // y //variável vertical

function setup() {

    createCanvas(400, 400);//criando cenário
    background(color(100, 0, 0));//cor do cenário
    cor = color(random(0, 255), random(0, 255), random(0,55));//cores aleatórias 
    posicaoHorizontal = 200;//valor variável
    posicaoVertical = 200;//valor variável 
    }
    
function draw() {//função de desenho

     fill (cor)// cor o circulo

    circle(posicaoHorizontal, posicaoVertical, 50);//posição e tamanho do circulo
  
    posicaoHorizontal+= random(0, 3);
  posicaoVertical +=random(-3, 3)
 
    if(mouseIsPressed) {//se mause precionado 
    cor = color(random(0, 255), random(0, 255), random(0,255),
random(0, 100));//cores aleatórias
    }


      
      
}



